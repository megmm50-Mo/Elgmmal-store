Elgmmal-store - بناء APK من الموبايل عبر GitHub Actions

محتويات الحزمة:
1) Elgmmal-store-android-source.zip : مشروع أندرويد التجريبي.
2) .github/workflows/build-apk.yml : وصفة بناء APK تلقائياً على GitHub.

الخطوات:
1. افتح github.com من Chrome وسجّل الدخول أو أنشئ حساباً.
2. اضغط + ثم New repository. الاسم: Elgmmal-store ، واختر Public أو Private ثم Create repository.
3. داخل المستودع اضغط Add file ثم Upload files.
4. ارفع الملفين الموجودين في هذه الحزمة: Elgmmal-store-android-source.zip وملف build-apk.yml. يجب وضع ملف YAML داخل المسار .github/workflows/build-apk.yml. لإنشاء المسار: Add file > Create new file، اكتب .github/workflows/build-apk.yml في خانة الاسم، والصق محتوى الملف من الحزمة، ثم Commit. وارفع ملف ZIP إلى جذر المستودع.
5. بعد حفظ الملفين افتح تبويب Actions، واختر Build Elgmmal-store APK، ثم Run workflow ثم Run workflow.
6. انتظر حتى تنتهي العملية بعلامة خضراء. افتح تشغيل البناء الناجح، وانزل إلى Artifacts، واضغط Elgmmal-store-debug-apk لتنزيل ZIP.
7. افتح ZIP الذي نزلته من تطبيق الملفات، واستخرج app-debug.apk، واضغط عليه للتثبيت. إذا طلب أندرويد السماح بالتثبيت من هذا المصدر، فعّل السماح للمتصفح/مدير الملفات ثم أعد التثبيت.

ملاحظات:
- قد تحتاج تفعيل عرض سطح المكتب في Chrome إذا لم تظهر أزرار GitHub جيداً.
- تأكد أن الملف المضغوط الأصلي في جذر المستودع بالاسم نفسه تماماً.
- هذا APK تجريبي ببيانات وربط وهميين؛ لا يستقبل أو يرسل رسائل حقيقية إلى واتساب أو تيك توك.
- لا ترفع كلمات مرور أو أكواد OTP أو مفاتيح API إلى GitHub أو داخل APK.
