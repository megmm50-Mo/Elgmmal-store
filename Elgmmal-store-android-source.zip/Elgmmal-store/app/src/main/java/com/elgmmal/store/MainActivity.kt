package com.elgmmal.store

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF172033)
private val Accent = Color(0xFF187A68)
private val Soft = Color(0xFFEAF4F1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ElgmmalApp() }
    }
}

data class Chat(val name: String, val channel: String, val preview: String, val unread: Int)
data class Staff(val name: String, val role: String, val active: Boolean)

@Composable
fun ElgmmalApp() {
    var page by remember { mutableStateOf("الرئيسية") }
    var isAdmin by remember { mutableStateOf(true) }
    var selectedChat by remember { mutableStateOf<Chat?>(null) }
    var reply by remember { mutableStateOf("") }
    var newTask by remember { mutableStateOf("") }
    var newStaff by remember { mutableStateOf("") }
    val tasks = remember { mutableStateListOf("متابعة طلب عميل جديد", "مراجعة رسائل تيك توك", "الاتصال بعميل مهتم") }
    val staff = remember { mutableStateListOf(Staff("موظف تجريبي", "موظف دعم", true)) }
    val chats = remember {
        listOf(
            Chat("أحمد محمد", "واتساب", "محتاج تفاصيل الطلب والسعر", 2),
            Chat("Sara Store", "تيك توك", "هل المنتج متوفر؟", 1),
            Chat("محمود علي", "واتساب", "شكراً، وصلتني المعلومات", 0),
            Chat("Fashion World", "تيك توك", "ممكن صور الألوان؟", 0)
        )
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Accent, secondary = Ink, background = Color(0xFFF5F7F8))) {
        Scaffold(
            topBar = {
                TopAppBarSimple(
                    title = if (selectedChat != null) selectedChat!!.name else "Elgmmal-store",
                    subtitle = if (selectedChat != null) "محادثة تجريبية • ${selectedChat!!.channel}" else "مركز إدارة التواصل والعملاء"
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("الرئيسية", "الرسائل", "المهام", "الفريق").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { selectedChat = null; page = item },
                            icon = {
                                Icon(
                                    when(item) {
                                        "الرئيسية" -> Icons.Default.Dashboard
                                        "الرسائل" -> Icons.Default.Chat
                                        "المهام" -> Icons.Default.CheckCircle
                                        else -> Icons.Default.Groups
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item, fontSize = 11.sp) }
                        )
                    }
                }
            },
            containerColor = Color(0xFFF5F7F8)
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                if (selectedChat != null) {
                    ChatScreen(selectedChat!!, reply, { reply = it }, {
                        reply = ""
                    })
                } else when (page) {
                    "الرئيسية" -> HomeScreen(isAdmin, { isAdmin = it }, chats.size, staff.size, tasks.size)
                    "الرسائل" -> InboxScreen(chats) { selectedChat = it }
                    "المهام" -> TasksScreen(tasks, newTask, { newTask = it }, {
                        if (newTask.isNotBlank()) { tasks.add(newTask.trim()); newTask = "" }
                    })
                    "الفريق" -> TeamScreen(isAdmin, staff, newStaff, { newStaff = it }, {
                        if (newStaff.isNotBlank()) { staff.add(Staff(newStaff.trim(), "موظف", true)); newStaff = "" }
                    }, { idx -> staff[idx] = staff[idx].copy(active = !staff[idx].active) })
                }
            }
        }
    }
}

@Composable
fun TopAppBarSimple(title: String, subtitle: String) {
    Surface(color = Color.White, shadowElevation = 1.dp) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text(subtitle, fontSize = 11.sp, color = Color.Gray)
            }
            Text("ES", color = Accent, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp,
                modifier = Modifier.background(Soft, RoundedCornerShape(12.dp)).padding(12.dp))
        }
    }
}

@Composable
fun HomeScreen(isAdmin: Boolean, onRole: (Boolean) -> Unit, chats: Int, staff: Int, tasks: Int) {
    Spacer(Modifier.height(16.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(if (isAdmin) "أهلاً بك، المدير 👋" else "أهلاً بك، الموظف 👋", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text("إليك ملخص العمل اليوم", color = Color.Gray, fontSize = 13.sp)
        }
        if (isAdmin) Text("مدير", color = Accent, fontWeight = FontWeight.Bold)
    }
    Spacer(Modifier.height(14.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatCard("المحادثات", chats.toString(), Icons.Default.Chat, Modifier.weight(1f))
        StatCard("الموظفون", staff.toString(), Icons.Default.Groups, Modifier.weight(1f))
    }
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatCard("المهام المفتوحة", tasks.toString(), Icons.Default.Assignment, Modifier.weight(1f))
        StatCard("القنوات", "2", Icons.Default.Hub, Modifier.weight(1f))
    }
    Spacer(Modifier.height(16.dp))
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("حالة الربط", fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(10.dp))
            ChannelRow("WhatsApp", "يتطلب ربط Meta الرسمي")
            HorizontalDivider()
            ChannelRow("TikTok", "يتطلب موافقة وصلاحيات API")
        }
    }
    Spacer(Modifier.height(12.dp))
    Text("ملاحظة: البيانات الحالية تجريبية وليست متصلة بحسابات حقيقية.", color = Color.Gray, fontSize = 12.sp)
    if (isAdmin) {
        TextButton(onClick = { onRole(false) }) { Text("معاينة واجهة الموظف") }
    } else {
        TextButton(onClick = { onRole(true) }) { Text("العودة لمعاينة المدير") }
    }
}

@Composable
fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) {
            Icon(icon, null, tint = Accent)
            Spacer(Modifier.height(8.dp))
            Text(value, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text(title, fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable
fun ChannelRow(name: String, status: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(name, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
        Text(status, color = Color.Gray, fontSize = 11.sp)
    }
}

@Composable
fun InboxScreen(chats: List<Chat>, onOpen: (Chat) -> Unit) {
    Spacer(Modifier.height(12.dp))
    Text("صندوق الوارد الموحد", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
    Text("معاينة محادثات من واتساب وتيك توك", fontSize = 12.sp, color = Color.Gray)
    Spacer(Modifier.height(8.dp))
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(chats) { chat ->
            Card(Modifier.fillMaxWidth().clickable { onOpen(chat) }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (chat.channel == "واتساب") "W" else "♪", color = Accent, fontWeight = FontWeight.Bold,
                        modifier = Modifier.background(Soft, RoundedCornerShape(12.dp)).padding(13.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(chat.name, fontWeight = FontWeight.Bold, color = Ink)
                        Text(chat.preview, fontSize = 12.sp, color = Color.Gray)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(chat.channel, fontSize = 11.sp, color = Accent)
                        if (chat.unread > 0) Text("${chat.unread} جديدة", fontSize = 10.sp, color = Color.White,
                            modifier = Modifier.background(Accent, RoundedCornerShape(8.dp)).padding(horizontal = 7.dp, vertical = 3.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun ChatScreen(chat: Chat, reply: String, onReply: (String) -> Unit, onSend: () -> Unit) {
    Spacer(Modifier.height(12.dp))
    Text("المحادثة مع ${chat.name}", fontWeight = FontWeight.Bold, color = Ink)
    Text("هذه محادثة توضيحية فقط؛ لا يتم إرسال رسائل فعلية.", color = Color.Gray, fontSize = 11.sp)
    Spacer(Modifier.height(18.dp))
    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(chat.preview, color = Ink)
            Spacer(Modifier.height(14.dp))
            Text("يمكن توصيل شاشة المحادثة بواجهة الرسائل الرسمية بعد إعداد الخادم والصلاحيات.", color = Color.Gray, fontSize = 12.sp)
        }
    }
    Spacer(Modifier.weight(1f))
    OutlinedTextField(reply, onReply, Modifier.fillMaxWidth(), placeholder = { Text("اكتب ردًا تجريبيًا...") }, maxLines = 3)
    Button(onClick = onSend, Modifier.fillMaxWidth().padding(top = 8.dp), enabled = reply.isNotBlank()) { Text("إرسال تجريبي") }
    Spacer(Modifier.height(12.dp))
}

@Composable
fun TasksScreen(tasks: List<String>, value: String, onValue: (String) -> Unit, onAdd: () -> Unit) {
    Spacer(Modifier.height(14.dp))
    Text("إدارة المهام", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
    OutlinedTextField(value, onValue, Modifier.fillMaxWidth(), label = { Text("مهمة جديدة") })
    Button(onClick = onAdd, Modifier.fillMaxWidth().padding(top = 8.dp), enabled = value.isNotBlank()) { Text("إضافة مهمة") }
    Spacer(Modifier.height(12.dp))
    LazyColumn {
        items(tasks) { task ->
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.RadioButtonUnchecked, null, tint = Accent)
                    Spacer(Modifier.width(10.dp))
                    Text(task, color = Ink)
                }
            }
        }
    }
}

@Composable
fun TeamScreen(isAdmin: Boolean, staff: List<Staff>, value: String, onValue: (String) -> Unit, onAdd: () -> Unit, onToggle: (Int) -> Unit) {
    Spacer(Modifier.height(14.dp))
    Text("إدارة فريق العمل", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Ink)
    Text("عدد الموظفين تحدده أنت من داخل النظام.", fontSize = 12.sp, color = Color.Gray)
    if (!isAdmin) {
        Text("هذه الشاشة متاحة للمدير فقط.", color = Color.Red)
        return
    }
    OutlinedTextField(value, onValue, Modifier.fillMaxWidth(), label = { Text("اسم الموظف الجديد") })
    Button(onClick = onAdd, Modifier.fillMaxWidth().padding(top = 8.dp), enabled = value.isNotBlank()) { Text("إنشاء موظف تجريبي") }
    Spacer(Modifier.height(12.dp))
    staff.forEachIndexed { index, member ->
        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(member.name, fontWeight = FontWeight.Bold, color = Ink)
                    Text(member.role + if (member.active) " • نشط" else " • موقوف", fontSize = 11.sp, color = Color.Gray)
                }
                TextButton(onClick = { onToggle(index) }) { Text(if (member.active) "إيقاف" else "تفعيل") }
            }
        }
    }
    Text("حسابات الموظفين الحقيقية وتسجيل الدخول والصلاحيات تحتاج خادمًا وقاعدة بيانات آمنة.", color = Color.Gray, fontSize = 11.sp)
}
